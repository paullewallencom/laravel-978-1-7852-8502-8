<?php

namespace MyCompany;

use Illuminate\Database\Eloquent\Model;

class Accommodation extends Model
{
    //
}
