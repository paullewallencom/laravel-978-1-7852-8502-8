<?php namespace MyCompany\Events;

abstract class Event {

	//

}
