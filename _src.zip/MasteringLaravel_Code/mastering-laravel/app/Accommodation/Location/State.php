<?php

namespace MyCompany\Accommodation\Location;

use Illuminate\Database\Eloquent\Model;

class State extends Model
{
    public $timestamps = false;
}
