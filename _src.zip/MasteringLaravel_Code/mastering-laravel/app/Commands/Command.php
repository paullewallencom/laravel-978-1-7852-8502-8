<?php namespace MyCompany\Commands;

abstract class Command {

	//

}
