<?php

namespace MyCompany\Accommodation;

use Illuminate\Database\Eloquent;
use Illuminate\Database\Eloquent\Model;

class Room extends Model
{
}
