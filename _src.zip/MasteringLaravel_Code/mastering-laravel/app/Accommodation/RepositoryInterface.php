<?php

namespace MyCompany\Accommodation;

interface RepositoryInterface {
    public function create($attributes);
}