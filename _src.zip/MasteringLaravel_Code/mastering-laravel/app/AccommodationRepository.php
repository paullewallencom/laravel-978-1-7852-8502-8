<?php

namespace MyCompany;

class AccommodationRepository
{
}
